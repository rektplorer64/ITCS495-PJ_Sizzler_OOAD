CREATE FUNCTION "regexp_replace"(citext, citext, text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE "sql"
AS
$$
SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text, $3, 'i');
$$;

ALTER FUNCTION "regexp_replace"(CITEXT, CITEXT, TEXT) OWNER TO "SizzlerAdmin";

