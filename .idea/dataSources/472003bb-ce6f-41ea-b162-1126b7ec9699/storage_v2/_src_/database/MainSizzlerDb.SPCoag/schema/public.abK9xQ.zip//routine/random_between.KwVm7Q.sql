CREATE FUNCTION "random_between"(low integer, high integer) RETURNS integer
    STRICT
    LANGUAGE "plpgsql"
AS
$$
BEGIN
   RETURN floor(random()* (high-low + 1) + low);
END;
$$;

ALTER FUNCTION "random_between"(INTEGER, INTEGER) OWNER TO "SizzlerAdmin";

