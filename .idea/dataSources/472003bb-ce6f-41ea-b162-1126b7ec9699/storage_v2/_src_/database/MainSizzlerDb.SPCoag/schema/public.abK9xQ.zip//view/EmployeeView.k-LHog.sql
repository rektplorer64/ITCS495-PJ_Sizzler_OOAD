CREATE VIEW "EmployeeView"
            ("employeeId", "firstname", "surname", "nickname", "birthdate", "age", "phoneNumbers", "email", "position",
             "educationLevel", "workAtBranch")
AS
SELECT "E"."employeeId",
       "E"."firstname",
       "E"."surname",
       "E"."nickname",
       "E"."birthdate",
       "E"."age",
       "E"."phoneNumbers",
       "E"."email",
       CASE
           WHEN "C"."employeeId" IS NOT NULL THEN 'Chef'::TEXT
           WHEN "BM"."employeeId" IS NOT NULL THEN 'Branch Manager'::TEXT
           WHEN "C2"."employeeId" IS NOT NULL THEN 'Cashier'::TEXT
           WHEN "KM"."employeeId" IS NOT NULL THEN 'Kitchen Manager'::TEXT
           WHEN "DM"."employeeId" IS NOT NULL THEN 'Delivery Man'::TEXT
           WHEN "KP"."employeeId" IS NOT NULL THEN 'Kitchen Porter'::TEXT
           ELSE NULL::TEXT
           END        AS "position",
       "E"."educationLevel",
       "E"."branchId" AS "workAtBranch"
FROM (SELECT "E_1"."employeeId",
             "E_1"."firstname",
             "E_1"."surname",
             "E_1"."nickname",
             "E_1"."birthdate",
             "E_1"."age",
             array_agg("ET"."telephoneNo") AS "phoneNumbers",
             "E_1"."email",
             "E3"."nameEnglish"            AS "educationLevel",
             "E_1"."branchId"
      FROM "Employee" "E_1"
               JOIN "EmployeeTelephone" "ET" ON "E_1"."employeeId" = "ET"."employeeId"
               JOIN "EducationLevelRef" "E3" ON "E_1"."educationLevelId" = "E3"."educationLevelId"
      GROUP BY "E_1"."employeeId", "E_1"."firstname", "E_1"."surname", "E_1"."nickname", "E_1"."email",
               "E3"."nameEnglish") "E"
         LEFT JOIN "Chef" "C" ON "E"."employeeId" = "C"."employeeId"
         LEFT JOIN "BranchManager" "BM" ON "E"."employeeId" = "BM"."employeeId"
         LEFT JOIN "Cashier" "C2" ON "E"."employeeId" = "C2"."employeeId"
         LEFT JOIN "KitchenManager" "KM" ON "E"."employeeId" = "KM"."employeeId"
         LEFT JOIN "DeliveryMan" "DM" ON "E"."employeeId" = "DM"."employeeId"
         LEFT JOIN "KitchenPorter" "KP" ON "E"."employeeId" = "KP"."employeeId";

ALTER TABLE "EmployeeView"
    OWNER TO "SizzlerAdmin";

