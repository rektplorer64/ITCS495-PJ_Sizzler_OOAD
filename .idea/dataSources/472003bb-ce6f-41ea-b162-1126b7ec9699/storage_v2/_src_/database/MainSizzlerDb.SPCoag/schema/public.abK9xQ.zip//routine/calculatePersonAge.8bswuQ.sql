create function "calculatePersonAge"(birthday date) returns integer
    immutable
    language plpgsql
as
$$
BEGIN
    RETURN extract(YEAR FROM CURRENT_DATE)
               - extract(YEAR FROM "birthday")
        + 1;
END
$$;

alter function "calculatePersonAge"(date) owner to "SizzlerAdmin";

