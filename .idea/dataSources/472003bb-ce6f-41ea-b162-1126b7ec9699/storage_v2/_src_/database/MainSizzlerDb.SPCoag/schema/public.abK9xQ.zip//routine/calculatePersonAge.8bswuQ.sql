CREATE FUNCTION "calculatePersonAge"(birthday date) RETURNS integer
    IMMUTABLE
    LANGUAGE "plpgsql"
AS
$$
BEGIN
    RETURN extract(YEAR FROM CURRENT_DATE)
               - extract(YEAR FROM "birthday")
        + 1;
END
$$;

ALTER FUNCTION "calculatePersonAge"(DATE) OWNER TO "SizzlerAdmin";

