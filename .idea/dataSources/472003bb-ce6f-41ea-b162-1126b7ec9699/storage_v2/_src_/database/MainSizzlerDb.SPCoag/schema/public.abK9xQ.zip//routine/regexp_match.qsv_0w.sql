CREATE FUNCTION "regexp_match"(citext, citext) RETURNS text[]
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE "sql"
AS
$$
SELECT pg_catalog.regexp_match( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

ALTER FUNCTION "regexp_match"(CITEXT, CITEXT) OWNER TO "SizzlerAdmin";

