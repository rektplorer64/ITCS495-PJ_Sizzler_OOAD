CREATE FUNCTION "calculateOrderItemPrice"("perUnitPrice" numeric, "perUnitTakeHomeFee" numeric, "perUnitDiscount" numeric, quantity integer
) RETURNS integer
    IMMUTABLE
    LANGUAGE "plpgsql"
AS
$$
BEGIN
    RETURN sum(("perUnitPrice" + coalesce("perUnitTakeHomeFee", 0) - coalesce("perUnitDiscount", 0)) * "quantity");
END
$$;

ALTER FUNCTION "calculateOrderItemPrice"(NUMERIC, NUMERIC, NUMERIC, INTEGER) OWNER TO "SizzlerAdmin";

