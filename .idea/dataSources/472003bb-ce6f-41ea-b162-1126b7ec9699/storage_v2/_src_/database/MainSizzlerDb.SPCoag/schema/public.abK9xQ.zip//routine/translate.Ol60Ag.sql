CREATE FUNCTION "translate"(citext, citext, text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE "sql"
AS
$$
SELECT pg_catalog.translate( pg_catalog.translate( $1::pg_catalog.text, pg_catalog.lower($2::pg_catalog.text), $3), pg_catalog.upper($2::pg_catalog.text), $3);
$$;

ALTER FUNCTION "translate"(CITEXT, CITEXT, TEXT) OWNER TO "SizzlerAdmin";

